function [cv,ct] = O2Solve(sparam,gparam,nreg,cv,ct)
    np = gparam.np;
    U = gparam.U;
    w = gparam.w;
    k = gparam.k;
    gam = gparam.gam;
    cBnd = gparam.cBnd;
    Rv = gparam.Rv;
    MCQ = gparam.MCQ;
    P50 = gparam.P50;
    nh = gparam.nh;
    H = gparam.H;
    C0 = gparam.C0;
    alb = gparam.alb;
    ns = nreg.ns;
    C2 = nreg.C2;
    C3 = nreg.C3;
    SA = nreg.SA;
    h = nreg.h;
    nv = nreg.nv;
    maxnewts = sparam.maxnewts;
    inner = sparam.inner;
    schtol = sparam.schtol;
    newtol = sparam.newtol;
    maxsch = sparam.maxsch;
    %Resolution dependent matrices
    C2SC2 = -(U/w)*C2'*SA*C2; 
    C = -(U/w)*C2'*SA*C3;
    kC3SC3 = -1*(k*h^3*speye(nv) + (U/w)*C3'*SA*C3);
    C3SC2 = -(U/w)*C3'*SA*C2;
    Rt = -h*gam*cBnd*make_Dirichlet_BC(ns,nv)*ones(nv,1);
    rhs_norm_2 = norm([Rv;Rt]);
    La = makeHelmEigens_692021(ns,-k/gam,3,h);
    a = 1/((ns(1)+1)*(ns(2)+1)*(ns(3)+1))/8;
    %Auxiliary local functions
    r = @(x) o2_residual(x,np,C,Rv,Rt,MCQ,C2SC2,P50,nh,H,C0,C3SC2,alb,kC3SC3,h,gam,ns);
    f = @(x) o2_objective(x,r);
    fu = @(x) o2_objective_unconstrained(x,r);
    JA = @(x) MCQ + C2SC2*spdiags(inv_hill_p(x,alb,P50,H,C0,nh),0,np,np);
    JC = @(x) C3SC2*spdiags(inv_hill_p(x,alb,P50,H,C0,nh),0,np,np);
    gft = @(x) (Jrtoper(r(x),x,np,JA,JC,kC3SC3,h,gam,ns,C))';
    %Newton steps
    i=0; rr2 = Inf; rrnewt2 = [];
    while (i<maxnewts)&&(rr2>newtol)
        bv = Rv - Anl(cv,MCQ,C2SC2,P50,nh,H,C0,alb) - C*ct;
        bt = Rt - Cnl(cv,C3SC2,P50,nh,H,C0,alb) - Boper(ct,kC3SC3,h,gam,ns);
        dJAk = decomposition(JA(cv));
        JCk = JC(cv);
        bb = bt - JCk*(dJAk\bv);
        sch = @(x) Boper(x,kC3SC3,h,gam,ns) - JCk*(dJAk\(C*x));
        dt = gmres(@(x) sch(x),bb,inner,schtol,maxsch, @(y) MDAprecon(y,a,La,ns));
        dv = dJAk\(bv - C*dt);
        i = i+1;
        gg = @(x) fu([cv;ct] + x*[dv;dt]);
        gp = @(x) gft([cv;ct] + x*[dv;dt])*[dv;dt];
        ah = linesearch_quadratic(gg,gp,2);
        cv = cv + ah*dv; ct = ct + ah*dt;
        cv = cv_feasible(cv,H,C0);
        res = r([cv;ct]); 
        if ~isreal(res)
            error('infeasible Newton iteration')
        end
        rr2 = norm(res)/rhs_norm_2
        rrnewt2 = [rrnewt2,rr2];
    end
    figure
    plot(rrnewt2,'-o')
    ax = gca;
    ax.YAxis.Scale = 'log';
    xlabel('Newton iterations')
    ylabel('relative residual in Euclidean norm')
    title(sprintf('Preconditioned Newton iterations with num voxels = %i',nv))
    drawnow
end