function L = makeHelmEigens_692021(sz,w,d,h)
    if d == 1
        nx = sz(1); hx = 1/(nx+1);
        L = 2 - 2*cos((1:nx)'*pi*hx) - h^2*w/d;
    elseif d == 2
        nx = sz(1); hx = 1/(nx+1);
        ny = sz(2); hy = 1/(ny+1);
        lambdax = 2 - 2*cos((1:nx)'*pi*hx) - h^2*w/d;
        lambday = 2 - 2*cos((1:ny)'*pi*hy) - h^2*w/d;
        L = repmat(lambdax,1,ny) + repmat(lambday',nx,1);
    elseif d == 3
        nx = sz(1); hx = 1/(nx+1);
        ny = sz(2); hy = 1/(ny+1);
        nz = sz(3); hz = 1/(nz+1);
        lambdax = 2 - 2*cos((1:nx)'*pi*hx) - h^2*w/d;
        lambday = 2 - 2*cos((1:ny)'*pi*hy) - h^2*w/d;
        lambdaz = 2 - 2*cos((1:nz)'*pi*hz) - h^2*w/d;
        L = repmat(lambdax,1,ny,nz) + repmat(lambday',nx,1,nz) + ...
        repmat(permute(lambdaz,[3 2 1]),nx,ny,1);
    end
end