function ctt = makeO2field_06222022(cv,ct,gparam,nreg)
    np = gparam.np;
    P50 = gparam.P50;
    nh = gparam.nh;
    H = gparam.H;
    C0 = gparam.C0;
    alb = gparam.alb;
    cBnd = gparam.cBnd;
    ns = nreg.ns;
    NodeINTCells = nreg.NodeINTCells;
    NodeMTCells = nreg.NodeMTCells;
    for i = 1:np
        indices = NodeINTCells{i};
        ct(indices) = inv_hill(cv(i),P50,nh,H,C0,alb);
        indices = NodeMTCells{i};
        ct(indices) = inv_hill(cv(i),P50,nh,H,C0,alb);
    end
    ctt = cBnd*ones(ns+2);
    ctt(2:end-1,2:end-1,2:end-1) = reshape(ct,ns);
end