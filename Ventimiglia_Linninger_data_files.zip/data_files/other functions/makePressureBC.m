function [D1,p] = makePressureBC(BC, np)
    bc1 = BC(:,1);
    % assign the value of 1 (Dirichlet) or 0 for Neumann
    D1 = sparse(bc1, bc1, BC(:,2), np, np);
    p = sparse(bc1, 1, BC(:,3),np, 1);
end