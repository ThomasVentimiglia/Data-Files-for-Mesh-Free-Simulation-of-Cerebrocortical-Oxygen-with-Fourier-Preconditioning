function o2vid(filename,tissueo2,xspan,yspan,alb,reverse)
    if reverse
        indices = 1:size(tissueo2,3);
    else
        indices = size(tissueo2,3):-1:1;
    end
    tissueo2 = permute(tissueo2,[2 1 3])/alb;
    cmin = 10; cmax = 68;
    xmin = min(xspan); xmax = max(xspan);
    ymin = min(yspan); ymax = max(yspan);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vid = VideoWriter(strcat(filename,'.avi'));
    open(vid)
    for i=indices
        imagesc('XData',xspan,'YData',yspan,'CData',tissueo2(:,:,i))
        cbar = colorbar;
        cbar.Label.String = 'pO_2 (mmHg)';
        clim([cmin cmax])
        colormap jet
        xlim([xmin xmax])
        ylim([ymin ymax])
        axis tight
        axis square
        xlabel('\mum')
        ylabel('\mum')
        frame = getframe(gcf);
        writeVideo(vid,frame);
    end
    close(vid)
end