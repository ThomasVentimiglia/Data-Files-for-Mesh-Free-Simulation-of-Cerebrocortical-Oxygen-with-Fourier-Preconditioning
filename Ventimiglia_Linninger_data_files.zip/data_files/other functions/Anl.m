function v = Anl(u,MCQ,C2SC2,P50,nh,H,C0,alb)
%nonlinear A matrix. Vessel-vessel combinations. Top-left block
    v = MCQ*u + C2SC2*inv_hill(u,P50,nh,H,C0,alb);
end