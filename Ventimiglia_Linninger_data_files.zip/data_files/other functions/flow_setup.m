function [ff, pp] = flow_setup(ptCoordMx, faceMx, dia, BC, C1, np, nf)
    [D1,ph] = makePressureBC(BC, np);
    ai = make_inverse_resistance(ptCoordMx, faceMx, dia, nf);
    E = (speye(np)-D1)*C1'; G = E*ai*C1 + D1;
    pp = G\ph;
    ff = ai*C1*pp; 
end