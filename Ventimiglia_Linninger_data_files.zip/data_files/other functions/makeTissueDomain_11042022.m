function nreg = makeTissueDomain_11042022(ptCoordMx, faceMx, C1, dia, bf,ns)
    %Grantian mass transfer
    %Construct tissue domain
    xMin = min(ptCoordMx(:,1)); xMax = max(ptCoordMx(:,1)); 
    yMin = min(ptCoordMx(:,2)); yMax = max(ptCoordMx(:,2));
    zMin = min(ptCoordMx(:,3)); zMax = max(ptCoordMx(:,3)); 
    len = [xMax - xMin, yMax - yMin, zMax - zMin];
    lMax = max(len); bfl = bf*lMax;
    h = (len(3) + 2*bfl)/(ns(3)+1);
    nv = prod(ns);
    xspan = (xMin - bfl):h:(xMin - bfl + h*ns(1) + h);
    yspan = (yMin - bfl):h:(yMin - bfl + h*ns(2) + h);
    zspan = (zMin - bfl):h:(zMin - bfl + h*ns(3) + h);

    %For each face make rotated cylinder with spherical endcaps
    nf = size(faceMx,1); MTCells = cell(nf,1); INTCells = cell(nf,1);
    inits = ptCoordMx(faceMx(:,2),:); terms = ptCoordMx(faceMx(:,3),:);
    faces = terms - inits;
    fl = vecnorm(faces,2,2);
    for i = 1:nf
        d = dia(i); dspan = h:h:(h*ceil((d-h)/h));
        [lowerMT, upperMT] = makeCapsule_tv(d,h,faces(i,:)'...
            ,inits(i,:)',ns,[xMin, yMin, zMin] - bfl);
        MTCells{i} = struct('half1',lowerMT,'half2',upperMT);
        lowerINT = []; upperINT = [];
        for j = 1:length(dspan)
            [ll, uu] = makeCapsule_tv(dspan(j),h,faces(i,:)'...
            ,inits(i,:)',ns,[xMin, yMin, zMin] - bfl);
            ll = ll(~ismember(ll,lowerMT));
            uu = uu(~ismember(uu,upperMT));
            lowerINT = [lowerINT;ll]; upperINT = [upperINT;uu];
        end
        INTCells{i} = struct('half1',lowerINT,'half2',upperINT);
        nf-i
    end
    
    %Make network to voxel mass transfer matrix and surface areas
    np = size(ptCoordMx,1); fspan = (1:nf)';
    C1init = sparse(fspan, faceMx(:,2)', true, nf, np);
    C1term = sparse(fspan, faceMx(:,3)', true, nf, np);
    NA = 0.5*pi*abs(C1')*(dia.*fl); %node surface areas
    nit = 0; nit2 = []; nit3 = []; nitsa = [];
    NodeINTCells = cell(np,1); NodeMTCells = cell(np,1);
    for i = 1:np
        MTind = []; INTind = [];
        initTo = fspan(C1init(:,i)); li = length(initTo);
        termTo = fspan(C1term(:,i)); lt = length(termTo);
        if li > 0
            for j = 1:li
                s = MTCells{initTo(j)};
                MTind = [MTind; s.half1];
                s = INTCells{initTo(j)};
                INTind = [INTind; s.half1];
            end
        end
        if lt > 0
            for j = 1:lt
                s = MTCells{termTo(j)};
                MTind = [MTind;s.half2];
                s = INTCells{termTo(j)};
                INTind = [INTind; s.half2];
            end
        end
        MTind = unique(MTind); INTind = unique(INTind);
        MTind = MTind(~ismember(MTind,INTind));
        NodeMTCells{i} = MTind; NodeINTCells{i} = INTind;
        ni = length(MTind);
        nit = nit + ni;
        nit2 = [nit2; repmat(i,ni,1)];
        nit3 = [nit3; MTind];
        nitsa = [nitsa; repmat(NA(i)/ni,ni,1)];
        np-i
    end
    C2 = sparse(1:nit,nit2,1,nit,np);
    C3 = sparse(1:nit,nit3,-1,nit,nv);
    SA = spdiags(nitsa,0,nit,nit);
    nreg.xspan = xspan;
    nreg.yspan = yspan;
    nreg.zspan = zspan;
    nreg.nv = nv;
    nreg.ns = ns;
    nreg.h = h;
    nreg.C2 = C2;
    nreg.C3 = C3;
    nreg.SA = SA;
    nreg.NodeMTCells = NodeMTCells;
    nreg.NodeINTCells = NodeINTCells;
end