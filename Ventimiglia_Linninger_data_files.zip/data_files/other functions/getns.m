function ns = getns(ptCoordMx,n,bf)
%n = num of interior points on longest edge of rectangular domain
%bf = buffer percent of longest edge
%ns = minimum number of interior points on each edge
    xMin = min(ptCoordMx(:,1)); xMax = max(ptCoordMx(:,1)); 
    yMin = min(ptCoordMx(:,2)); yMax = max(ptCoordMx(:,2));
    zMin = min(ptCoordMx(:,3)); zMax = max(ptCoordMx(:,3)); 
    len = [xMax - xMin, yMax - yMin, zMax - zMin];
    lMax = max(len); bfl = bf*lMax;
    h = (lMax + 2*bfl)/(n+1);
    ns = ceil((len + 2*bfl)/h) - 1;
end