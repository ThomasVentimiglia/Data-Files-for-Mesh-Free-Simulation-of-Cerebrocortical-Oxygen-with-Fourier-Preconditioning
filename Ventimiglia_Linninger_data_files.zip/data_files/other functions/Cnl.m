function v = Cnl(u,C3SC2,P50,nh,H,C0,alb)
    v = C3SC2*inv_hill(u,P50,nh,H,C0,alb);
end