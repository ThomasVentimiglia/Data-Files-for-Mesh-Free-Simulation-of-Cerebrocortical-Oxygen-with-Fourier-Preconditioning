% Lin 2/9/2021 --- this version avoids the ones vector generation
function C1 = ConnectivityMx3(nf,np,faceMx)
    fi = 1:nf;
    p1 = faceMx(:,2)'; p2 = faceMx(:,3)'; % P1IDx   % P2 Idx
    C1 = sparse(fi, p1, 1,nf,np)+sparse(fi,p2,-1,nf,np); % col 1 plus col2 matrices
end