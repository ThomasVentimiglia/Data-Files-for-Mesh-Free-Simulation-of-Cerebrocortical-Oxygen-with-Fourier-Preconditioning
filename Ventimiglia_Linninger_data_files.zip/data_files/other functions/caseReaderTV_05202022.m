function [faceMx,ptCoordMx,dia,BC,cBCMx,C1,np,nf,nt] = caseReaderTV_05202022(filename)
    myfileName = strcat(filename,'.fMx'); faceMx = load(myfileName);
    myfileName = strcat(filename,'.pMx'); ptCoordMx = load(myfileName); %microns
    myfileName = strcat(filename,'.dia'); dia = load(myfileName); %microns
    myfileName = strcat(filename,'.BC'); BC = load(myfileName);
    myfileName = strcat(filename,'.cBC'); cBCMx = load(myfileName);
    np = length(ptCoordMx); nf = length(faceMx(:,2)); nt = np + nf;
    C1 = ConnectivityMx3(nf,np,faceMx);
end