function cv = p2c_hill(P,P50,nh,H,C0)
    %plasma PO2 (mmHg) to total concentration (Mol/L) via Hill equation
    cv = H*C0*(P.^nh)./(P.^nh + P50^nh);
end