function f = o2_objective(x,r)
    r = r(x);
    if isreal(r)
        f = 0.5*(r'*r);
    else
        f = NaN;
    end
end