function v = Bopert(u,kC3SC3,h,gam,ns)
    %B matrix. Tissue-tissue interactions. Lower right block
    v = -h*gam*KOper(u,ns) + kC3SC3'*u;
end