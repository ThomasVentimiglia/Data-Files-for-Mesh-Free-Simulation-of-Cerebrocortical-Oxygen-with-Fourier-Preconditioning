function Dbc = make_Dirichlet_BC(ns,nv)
    ex = zeros(ns); ex1 = zeros(ns);
    ex1(:,:,1) = 1; ex = ex + ex1; ex1(:,:,:) = 0;
    ex1(:,:,end) = 1; ex = ex + ex1; ex1(:,:,:) = 0;
    ex1(:,1,:) = 1; ex = ex + ex1; ex1(:,:,:) = 0;
    ex1(:,end,:) = 1; ex = ex + ex1; ex1(:,:,:) = 0;
    ex1(1,:,:) = 1; ex = ex + ex1; ex1(:,:,:) = 0;
    ex1(end,:,:) = 1; ex = ex + ex1;
    ex = ex(:);
    Dbc = spdiags(ex,0,nv,nv);
end