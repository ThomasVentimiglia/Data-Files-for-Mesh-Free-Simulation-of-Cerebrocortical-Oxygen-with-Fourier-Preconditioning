function ai = make_inverse_resistance(ptCoordMx, faceMx, dia, nf ) %mmHg*s/um^3
    mu=5.3317E-7*60; %Viscosity in mmHg*s
    f=128*mu/pi;   
    l= vecnorm((ptCoordMx(faceMx(:,2),:)-ptCoordMx(faceMx(:,3),:)),2,2);
    d4 = dia.^4;
    r = d4./(l*f);
    ai = spdiags(r(:),0,nf,nf); % avoid loop
end