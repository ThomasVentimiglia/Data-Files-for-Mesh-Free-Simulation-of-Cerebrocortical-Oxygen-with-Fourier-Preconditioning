function [Do, Di] = readConvectionBC(cBCMx, np)
[lines, ~] = find(cBCMx(:,2)==4); % tn nodes with outflow bc
ni = cBCMx(lines,1);
Do = sparse(ni, ni, 1, np, np);
[lines, ~] = find(cBCMx(:,2)==3); % tn nodes with inflow bc
ni = cBCMx(lines,1);
Di = sparse(ni, ni, 1, np, np);
end