function qCM = ConvectionMx2(nf,faceMx,ff)
    fi = 1:nf;
    p1 = faceMx(:,2)'; p2 = faceMx(:,3)';
    qCM = sparse([fi,fi], [p1,p2], [max(ff,0)', -max(-ff,0)']);
end