function cv = cv_feasible(cv,H,C0)
    hi = max(cv(cv<H*C0));
    cv(cv>=hi) = hi;
    lo = min(cv(cv>0));
    cv(cv<=0) = lo; 
end