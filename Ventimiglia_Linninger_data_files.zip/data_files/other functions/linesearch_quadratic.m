function ah = linesearch_quadratic(g,gp,a)
    g0 = g(0); gp0 = gp(0); ga = g(a);
    ah = gp0*a^2/(2*(gp0*a+g0-ga));
end