function out = MDAprecon(in,a,La,ns)
    in = reshape(in,ns);
    in = dtt3D(in,5);
    in = in./La;
    in = a*dtt3D(in,5);
    out = in(:);
end