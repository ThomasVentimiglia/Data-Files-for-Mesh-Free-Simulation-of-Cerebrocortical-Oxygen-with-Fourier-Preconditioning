function rr = o2_residual(x,np,C,Rv,Rt,MCQ,C2SC2,P50,nh,H,C0,C3SC2,alb,kC3SC3,h,gam,ns)
    xv = x(1:np); xt = x(np+1:end);
    rv = Anl(xv,MCQ,C2SC2,P50,nh,H,C0,alb) + C*xt - Rv;
    rt = Cnl(xv,C3SC2,P50,nh,H,C0,alb) + Boper(xt,kC3SC3,h,gam,ns) - Rt;
    rr = [rv;rt];
end