function cp = inv_hill(cv,P50,nh,H,C0,alb)
%total concentration cv (bound plus free O2) to plasma concentration Mol/L
    cp = alb*P50*(cv./(H*C0-cv)).^(1/nh);
end