function sp = inv_hill_p(y,alb,P50,H,C0,nh)
    sp = (alb*P50*H*C0/nh)*(y.^((1-nh)/nh)).*((H*C0-y).^((-nh-1)/nh));
end