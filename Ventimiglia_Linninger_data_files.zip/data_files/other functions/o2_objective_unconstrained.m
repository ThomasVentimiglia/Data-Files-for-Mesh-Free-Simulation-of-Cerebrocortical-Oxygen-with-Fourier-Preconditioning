function f = o2_objective_unconstrained(x,r)
    r = r(x);
    f = 0.5*(r'*r);
end