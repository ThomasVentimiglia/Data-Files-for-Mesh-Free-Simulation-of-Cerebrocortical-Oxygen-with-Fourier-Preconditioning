function [lower, upper] = makeCapsule_tv(d,h,face,init,ns,lims)
    %Anonymous functions for rotation matrix
    %https://math.stackexchange.com/questions/180418/calculate-rotation-matrix-to-align-vector-a-to-vector-b-in-3d
    ssc = @(v) [0 -v(3) v(2); v(3) 0 -v(1); -v(2) v(1) 0];
    RU = @(A,B) eye(3) + ssc(cross(A,B)) + ...
     ssc(cross(A,B))^2*(1-dot(A,B))/(norm(cross(A,B))^2);
    A = [0;0;1];
    
    r = d/2; l = norm(face);
    radials = ceil(4*pi*r/h);
    if mod(radials,2) == 1
        radials = radials + 1;
    end
    if radials == 2
        radials = 4;
    end
    [xs,ys,zs] = sphere(radials);
    xs = r*xs(:); ys = r*ys(:); zs = r*zs(:);
    spherePtCoordMx = [xs,ys,zs];
    spherePtCoordMxLower = spherePtCoordMx(zs<=0,:,:);
    spherePtCoordMxUpper = spherePtCoordMx(zs>=0,:,:);
    spherePtCoordMxUpper(:,3) = spherePtCoordMxUpper(:,3) + l;
    rings = ceil(2*l/h);
    if mod(rings,2) == 1
        rings = rings + 1;
    end
    [xc,yc,zc] = cylinder(r*ones(rings,1),radials);
    xc = xc(:); yc = yc(:); zc = l*zc(:);
    cylPtCoordMx = [xc, yc, zc]; %Cylinder point coordinate matrix
    cylPtCoordMxLower = cylPtCoordMx(zc<=l/2,:,:);
    cylPtCoordMxUpper = cylPtCoordMx(zc>=l/2,:,:);
    B = face/l;
    if isequal(B,[0;0;-1])
        RM = [0 0 0; 0 0 0; 0 0 -1];
    elseif isequal(B,A)
        RM = eye(3);
    else
        RM = RU(A,B);
    end
    %Rotate and translate points of cylindrical capsule
    sphereLowerRot = (RM*spherePtCoordMxLower' + init)';
    sphereUpperRot = (RM*spherePtCoordMxUpper' + init)';
    cylLowerRot = (RM*cylPtCoordMxLower' + init)';
    cylUpperRot = (RM*cylPtCoordMxUpper' + init)';
    %Snap to mesh obtain global voxel indices
    %Lower Sphere
    ii = floor((sphereLowerRot(:,1) - lims(1))/h) + 1;
    jj = floor((sphereLowerRot(:,2) - lims(2))/h) + 1;
    kk = floor((sphereLowerRot(:,3) - lims(3))/h) + 1;
    sphereLowerInd = unique(sub2ind(ns,ii,jj,kk));
    %Upper Sphere
    ii = floor((sphereUpperRot(:,1) - lims(1))/h) + 1;
    jj = floor((sphereUpperRot(:,2) - lims(2))/h) + 1;
    kk = floor((sphereUpperRot(:,3) - lims(3))/h) + 1;
    sphereUpperInd = unique(sub2ind(ns,ii,jj,kk));
    %Lower cylinder
    ii = floor((cylLowerRot(:,1) - lims(1))/h) + 1;
    jj = floor((cylLowerRot(:,2) - lims(2))/h) + 1;
    kk = floor((cylLowerRot(:,3) - lims(3))/h) + 1;
    cylLowerInd = unique(sub2ind(ns,ii,jj,kk));
    %Upper cylinder
    ii = floor((cylUpperRot(:,1) - lims(1))/h) + 1;
    jj = floor((cylUpperRot(:,2) - lims(2))/h) + 1;
    kk = floor((cylUpperRot(:,3) - lims(3))/h) + 1;
    cylUpperInd = unique(sub2ind(ns,ii,jj,kk));
    % Outputs
    lower = [cylLowerInd; sphereLowerInd];
    upper = [cylUpperInd; sphereUpperInd];
end
