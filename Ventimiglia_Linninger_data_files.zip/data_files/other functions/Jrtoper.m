function u = Jrtoper(v,x,np,JA,JC,kC3SC3,h,gam,ns,C)
    vv = v(1:np); vt = v(np+1:end);
    uv = JA(x)'*vv + JC(x)'*vt;
    ut = C'*vv + Bopert(vt,kC3SC3,h,gam,ns);
    u = [uv;ut];
end