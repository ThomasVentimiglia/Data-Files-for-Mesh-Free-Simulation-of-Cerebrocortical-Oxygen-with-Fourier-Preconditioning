clear,clc
%Address to network .cs31 files
filename = ...
    'C:\Users\Thomas\Documents\MATLAB\data_files\network files\S3x3.cs31';
%Load network data
[gparam.faceMx,gparam.ptCoordMx,gparam.dia,gparam.BC,gparam.cBC,gparam.C1,gparam.np,gparam.nf,gparam.nt] = caseReaderTV_05202022(filename);
%Compute blood flow simulation
[gparam.ff, gparam.pp] = flow_setup(gparam.ptCoordMx, gparam.faceMx, gparam.dia, gparam.BC, gparam.C1, gparam.np, gparam.nf);
%Read convection boundary conditions
[gparam.Do, gparam.Di] = readConvectionBC(gparam.cBC, gparam.np);
%tissue resolution independent parameters
gparam.C0 = 0.02; %Mol/L total concentration at 100% saturation
gparam.H = 0.4; %Hematocrit
gparam.nh = 2.59; %Hill coefficient
gparam.P50 = 40.2; %mmHg Plasma partial pressure at 50% saturation
gparam.alb = 1.2e-6; %Mol/L/mmHg solubility of oxygen in plasma
gparam.aPO2 = 68; %mmHg arterial PO2 (plasma)
gparam.tPO2 = 40; %mmHg ambient tissue PO2 (boundary condition)
gparam.U = 1.77e3; %um^2/s permeability of vessel wall
gparam.w = 1; %um width of vessel wall
gparam.gam = 1.8e3; %um^2/s diffusivity of O2 in tissue
gparam.k = 0.4; %1/s 1st order reaction rate
gparam.bf = 0.05; %buffer space = percent of longest side
gparam.cInit = p2c_hill(gparam.aPO2,gparam.P50,gparam.nh,gparam.H,gparam.C0); %convert arterial PO2 to concentration
gparam.cBnd = gparam.alb*gparam.tPO2;
gparam.MCQ = -gparam.C1'*ConvectionMx2(gparam.nf, gparam.faceMx, gparam.ff) + spdiags(gparam.Do*(gparam.C1)'*gparam.ff,0,gparam.np,gparam.np); %Mc + Qout
gparam.Rv = -gparam.cInit*spdiags(gparam.Di*(gparam.C1)'*gparam.ff,0,gparam.np,gparam.np)*ones(gparam.np,1);
%Solver parameters
sparam.maxnewts = 10; %maximum newton iterations
sparam.inner = 10; %number of inner iterations per restart in GMRES
sparam.schtol = 1e-6; %GMRES goal for residual error tolerance (computing search direction)
sparam.newtol = 1e-6; %tolerance for Newton method
sparam.maxsch = 2; %maximum GMRES outer iterations for search direction
%Generate low res network to voxel registry
n = 2^7-1; 
ns = getns(gparam.ptCoordMx,n,gparam.bf);
%Make tissue domain and problem formulation for lowest resolution
nreg = makeTissueDomain_11042022(gparam.ptCoordMx, gparam.faceMx, gparam.C1, gparam.dia, gparam.bf,ns);
%Initial guess
cv = gparam.cInit*ones(gparam.np,1);
ct = gparam.cBnd*ones(nreg.nv,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[cv,ct] = O2Solve(sparam,gparam,nreg,cv,ct);
ctt = makeO2field_06222022(cv,ct,gparam,nreg);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Interpolate to get initial guess for next resolution level
nsold = ns;
n = 2^8-1;
ns = getns(gparam.ptCoordMx,n,gparam.bf);
[Xq,Yq,Zq] = meshgrid(linspace(1,nsold(1)+2,ns(1)+2),linspace(1,nsold(2)+2,ns(2)+2),linspace(1,nsold(3)+2,ns(3)+2));
ctt = permute(ctt,[2 1 3]);
ctt = interp3(ctt,Xq,Yq,Zq);
ctt = permute(ctt,[2 1 3]);
clear Xq Yq Zq
ctt = ctt(2:end-1,2:end-1,2:end-1); ct = ctt(:);
nreg = makeTissueDomain_11042022(gparam.ptCoordMx, gparam.faceMx, gparam.C1, gparam.dia, gparam.bf,ns);
[cv,ct] = O2Solve(sparam,gparam,nreg,cv,ct);
ctt = makeO2field_06222022(cv,ct,gparam,nreg);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Interpolate to get initial guess for next resolution level
nsold = ns;
n = 2^9-1;
ns = getns(gparam.ptCoordMx,n,gparam.bf);
[Xq,Yq,Zq] = meshgrid(linspace(1,nsold(1)+2,ns(1)+2),linspace(1,nsold(2)+2,ns(2)+2),linspace(1,nsold(3)+2,ns(3)+2));
ctt = permute(ctt,[2 1 3]);
ctt = interp3(ctt,Xq,Yq,Zq);
ctt = permute(ctt,[2 1 3]);
clear Xq Yq Zq
ctt = ctt(2:end-1,2:end-1,2:end-1); ct = ctt(:);
nreg = makeTissueDomain_11042022(gparam.ptCoordMx, gparam.faceMx, gparam.C1, gparam.dia, gparam.bf,ns);
[cv,ct] = O2Solve(sparam,gparam,nreg,cv,ct);
ctt = makeO2field_06222022(cv,ct,gparam,nreg);
%make video and save workspace as .ct file
figure
o2vid('s3x3',ctt,nreg.xspan,nreg.yspan,gparam.alb,false);
save('s3x3.ct','gparam','sparam','nreg','ctt','cv','-v7.3')